package exceptions;

public class BuscaInvalidaException extends Exception {
    public BuscaInvalidaException(String message) {
        super(message);
    }
}
