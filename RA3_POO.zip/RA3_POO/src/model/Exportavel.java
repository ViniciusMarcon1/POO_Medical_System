package model;

public interface Exportavel {
    String toCsv();
}
